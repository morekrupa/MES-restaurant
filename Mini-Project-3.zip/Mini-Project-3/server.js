const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const bcrypt = require('bcrypt'); // Added bcrypt for hashing
const port = 3019;

const app = express();

app.use(express.static(path.join(__dirname)));
app.use(express.urlencoded({ extended: true }));

mongoose.connect('mongodb://127.0.0.1:27017/customers');
const db = mongoose.connection;
db.once('open', () => {
    console.log("mongodb connection successful");
});

const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String,
    address: String
});

const Users = mongoose.model('data', userSchema);

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

app.get('/main', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.post('/post', async (req, res) => {
    try {
        const { name, email, password, address } = req.body;
        
        // Hash password before saving
        const hashedPassword = await bcrypt.hash(password, 10);
        
        const user = new Users({
            name,
            email,
            password: hashedPassword, // Store hashed password
            address
        });

        await user.save();
        console.log(user);

        res.send(`
            <script>
                alert('Sign up successful!');
                setTimeout(function() {
                    window.location.href = '/index-login.html';
                }, 500);
            </script>
        `);
    } catch (error) {
        console.error(error);
        res.status(500).send("Error submitting form");
    }
});

app.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        const user = await Users.findOne({ email });
        if (!user) {
            return res.send(`
                <script>
                    alert('Invalid email or password');
                    window.location.href = '/';
                </script>
            `);
        }

        // Compare hashed password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.send(`
                <script>
                    alert('Invalid email or password');
                    window.location.href = '/';
                </script>
            `);
        }

        res.send(`
            <script>
                alert('Login successful!');
                setTimeout(function() {
                    window.location.href = '/index-login.html';
                }, 500);
            </script>
        `);
    } catch (error) {
        console.error(error);
        res.status(500).send("Error logging in");
    }
});

app.listen(port, () => {
    console.log("server started");
});